package com.dynamicpill.module;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Black capsule with an indicator dot (right) and a small charging bolt (left). */
public class PillView extends View {
    private static final int BOLT_GREEN = 0xFF34C759;
    /** One full blink (dim and back) takes this long. */
    private static final long BLINK_PERIOD_MS = 1000;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bolt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path boltPath = new Path();
    private float borderPx = 0f;
    private int strokeColor = 0xFFFFFFFF;

    private boolean dotOn = true;
    private int dotColor = 0xFFFFFFFF;
    private boolean charging = false;

    private float dotFactor = 1f;     // dot blink (new notification)
    private float strokeFactor = 1f;  // outline blink (call)
    private ValueAnimator dotAnim, strokeAnim;

    public PillView(Context context) {
        super(context);
        paint.setColor(0xFF000000); // pure dark black, full alpha
        paint.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        dot.setStyle(Paint.Style.FILL);
        bolt.setStyle(Paint.Style.FILL);
        bolt.setColor(BOLT_GREEN);
    }

    /** Border thickness in pixels; 0 = no border. */
    public void setBorder(float px) {
        if (px != borderPx) {
            borderPx = Math.max(0f, px);
            invalidate();
        }
    }

    /** Border colour (white normally, green while charging or in a call). */
    public void setStrokeColor(int color) {
        if (strokeColor != color) {
            strokeColor = color;
            invalidate();
        }
    }

    /** 0..100 percent; 100 = fully solid black. */
    public void setPillAlpha(int percent) {
        int a = Math.round(255f * Math.max(0, Math.min(100, percent)) / 100f);
        if (paint.getAlpha() != a) {
            paint.setAlpha(a);
            invalidate();
        }
    }

    /** Indicator dot inside the pill: shown or not, and its colour. */
    public void setDot(boolean on, int color) {
        if (on != dotOn || color != dotColor) {
            dotOn = on;
            dotColor = color;
            invalidate();
        }
    }

    /** Small green lightning bolt on the left side while the phone is charging. */
    public void setBolt(boolean on) {
        if (on != charging) {
            charging = on;
            invalidate();
        }
    }

    private ValueAnimator startBlink(final boolean forDot) {
        ValueAnimator a = ValueAnimator.ofFloat(1f, 0.1f);
        a.setDuration(BLINK_PERIOD_MS / 2);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.addUpdateListener(v -> {
            if (forDot) dotFactor = (Float) v.getAnimatedValue();
            else strokeFactor = (Float) v.getAnimatedValue();
            invalidate();
        });
        a.start();
        return a;
    }

    /** Makes the dot fade out and in once per second. */
    public void setBlink(boolean on) {
        if (on) {
            if (dotAnim == null) dotAnim = startBlink(true);
        } else if (dotAnim != null) {
            dotAnim.cancel();
            dotAnim = null;
            dotFactor = 1f;
            invalidate();
        }
    }

    /** Makes the outline fade out and in once per second (call). */
    public void setStrokeBlink(boolean on) {
        if (on) {
            if (strokeAnim == null) strokeAnim = startBlink(false);
        } else if (strokeAnim != null) {
            strokeAnim.cancel();
            strokeAnim = null;
            strokeFactor = 1f;
            invalidate();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (dotAnim != null) { dotAnim.cancel(); dotAnim = null; dotFactor = 1f; }
        if (strokeAnim != null) { strokeAnim.cancel(); strokeAnim = null; strokeFactor = 1f; }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        rect.set(0, 0, w, h);
        float r = h / 2f;
        canvas.drawRoundRect(rect, r, r, paint);
        if (borderPx > 0f) {
            stroke.setColor(strokeColor);
            stroke.setAlpha(Math.round(255f * strokeFactor));
            stroke.setStrokeWidth(borderPx);
            float in = borderPx / 2f;
            rect.set(in, in, w - in, h - in);
            float rr = Math.max(0f, h / 2f - in);
            canvas.drawRoundRect(rect, rr, rr, stroke);
        }

        if (dotOn) {
            dot.setColor(dotColor);
            dot.setAlpha(Math.round(255f * dotFactor));
            canvas.drawCircle(w - h * 0.5f, h / 2f, h * 0.16f, dot);
        }

        if (charging) drawBolt(canvas, h);
    }

    /** Small lightning bolt, centred in the left cap of the pill. */
    private void drawBolt(Canvas canvas, float h) {
        float bh = h * 0.46f;
        float bw = bh * 0.7f;
        float x0 = h * 0.5f - bw / 2f;
        float y0 = h * 0.5f - bh / 2f;
        boltPath.reset();
        boltPath.moveTo(x0 + 0.62f * bw, y0);
        boltPath.lineTo(x0 + 0.08f * bw, y0 + 0.56f * bh);
        boltPath.lineTo(x0 + 0.46f * bw, y0 + 0.56f * bh);
        boltPath.lineTo(x0 + 0.34f * bw, y0 + bh);
        boltPath.lineTo(x0 + 0.92f * bw, y0 + 0.42f * bh);
        boltPath.lineTo(x0 + 0.54f * bw, y0 + 0.42f * bh);
        boltPath.close();
        canvas.drawPath(boltPath, bolt);
    }
}
